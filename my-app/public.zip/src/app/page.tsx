

import Header from '../components/Header'
import Navbarr from '@/components/Navbarr';
import Main from '../components/Main'
import Footer from '../components/Footer'
import 'bootstrap/dist/css/bootstrap.min.css';
import '../components/App.css'



 const App = () => {

  return (
    <>
      <Header/>
      <Navbarr/>
      <Main/>
      <Footer/>
    </>
      
    
  );
}

export default App;