

const parceiros =()=>{
    return(
        <>
            <p>Ola</p>
        </>
    );
}
export default parceiros;