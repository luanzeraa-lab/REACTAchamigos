"use client";



import {  Button } from 'react-bootstrap';
import Image from 'next/image';
import { title } from 'process';


const Header = () => {



    return (
        <div id='container'>
            <title>Home</title>

            
            <div className="flex flex-col lg:flex-row justify-evenly items-center bg-[#FFECCF] p-4">
                  
                <Image 
                    className=" mt-4 sm:mt-0 sm:ml-12 max-w-full h-auto lg:order-2"
                    src="/images/logocerto.png"
                    width={800}
                    height={200}
                    alt="logo"
                />

                <a
                    id="login"
                    href="login.html"
                    className=" text-decoration-none text-black rounded-full px-5 py-2 border-2 bg-[#ff8110]
                     hover:scale-150 transition-transform"
                >
                    Login
                </a>
                
               
                
        
                <div id=" logo_pesquisa2" className="flex  mt-4 sm:mt-10 bg-[#ff8110] rounded-full justify-center w-full sm:w-auto order-3">
                    <input
                        className="bg-[#ff8110] border-2 rounded-full placeholder:text-center text-black py-2 px-4 w-full sm:w-auto"
                        id="pesquisar"
                        placeholder="Pesquisar..."
                    />
                    <Button className="border-2 border-black" variant="light">
                    <Image 
                      className="w-full h-8 mr-2 "
                      src="/images/gatinho.png" 
                      width={800}
                      height={200}
                      alt="Ícone de Pesquisa"  />
                        
                    </Button>
                </div>
            </div>     
        </div>
    );
}

export default Header;